public class WebDeveloper extends Programmer{
    public WebDeveloper(String name, String ssn){
        super(name, ssn);
        setJobDescription("Web Developer");
    }
}